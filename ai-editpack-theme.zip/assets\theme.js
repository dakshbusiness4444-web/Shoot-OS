/* ============================================================
   AI EDIT PACK — Theme JavaScript
   GSAP + ScrollTrigger + Custom Cursor + Interactions
   ============================================================ */

(function () {
  'use strict';

  // ─── Register GSAP plugins ──────────────────────────────
  gsap.registerPlugin(ScrollTrigger, CustomEase);
  CustomEase.create('smooth', 'M0,0 C0.25,0.1 0.25,1 1,1');
  CustomEase.create('spring', 'M0,0 C0.34,1.56 0.64,1 1,1');

  // ─── Utility ─────────────────────────────────────────────
  const qs  = (sel, ctx = document) => ctx.querySelector(sel);
  const qsa = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
  const isMobile = () => window.innerWidth < 768;
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ─── 1. PAGE LOADER ──────────────────────────────────────
  function initLoader() {
    const loader  = qs('#pageLoader');
    const fill    = qs('#loaderFill');
    if (!loader) return;

    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 18 + 5;
      if (progress >= 95) {
        progress = 95;
        clearInterval(interval);
      }
      if (fill) fill.style.width = progress + '%';
    }, 120);

    window.addEventListener('load', () => {
      clearInterval(interval);
      if (fill) fill.style.width = '100%';

      setTimeout(() => {
        gsap.to(loader, {
          opacity: 0,
          duration: 0.6,
          ease: 'power2.inOut',
          onComplete: () => {
            loader.style.display = 'none';
            initHeroAnimation();
          }
        });
      }, 300);
    });

    // Fallback — force hide after 4s
    setTimeout(() => {
      if (loader && loader.style.display !== 'none') {
        loader.style.display = 'none';
        initHeroAnimation();
      }
    }, 4000);
  }

  // ─── 2. CUSTOM CURSOR ────────────────────────────────────
  function initCursor() {
    if (isMobile() || !window.matchMedia('(hover: hover)').matches) return;

    const outer = qs('#cursorOuter');
    const dot   = qs('#cursorDot');
    if (!outer || !dot) return;

    let mx = 0, my = 0;
    let ox = 0, oy = 0;

    document.addEventListener('mousemove', (e) => {
      mx = e.clientX;
      my = e.clientY;
      gsap.to(dot, { x: mx, y: my, duration: 0.1, ease: 'none' });
    });

    // Outer follows with lag
    gsap.ticker.add(() => {
      ox += (mx - ox) * 0.12;
      oy += (my - oy) * 0.12;
      gsap.set(outer, { x: ox, y: oy });
    });

    // Magnetic elements grow cursor
    const magnetTargets = qsa('a, button, [data-magnetic], .pack-card, .faq-question, .btn');
    magnetTargets.forEach(el => {
      el.addEventListener('mouseenter', () => {
        document.body.classList.add('cursor-active');
        gsap.to(outer, { scale: 1.6, duration: 0.3, ease: 'spring' });
      });
      el.addEventListener('mouseleave', () => {
        document.body.classList.remove('cursor-active');
        gsap.to(outer, { scale: 1, duration: 0.3, ease: 'spring' });
      });
    });

    document.addEventListener('mousedown', () => {
      gsap.to(dot, { scale: 0.6, duration: 0.1 });
      gsap.to(outer, { scale: 0.85, duration: 0.1 });
    });
    document.addEventListener('mouseup', () => {
      gsap.to(dot, { scale: 1, duration: 0.2, ease: 'spring' });
      gsap.to(outer, { scale: 1, duration: 0.2, ease: 'spring' });
    });

    // Show cursor on mouse enter
    document.addEventListener('mouseenter', () => {
      gsap.to([outer, dot], { opacity: 1, duration: 0.3 });
    });
    document.addEventListener('mouseleave', () => {
      gsap.to([outer, dot], { opacity: 0, duration: 0.3 });
    });
  }

  // ─── 3. HEADER SCROLL STATE ──────────────────────────────
  function initHeader() {
    const header = qs('.site-header');
    if (!header) return;

    ScrollTrigger.create({
      start: 80,
      onEnter:      () => header.classList.add('scrolled'),
      onLeaveBack:  () => header.classList.remove('scrolled'),
    });

    // Mobile nav toggle
    const toggle = qs('.nav-toggle');
    const mobileNav = qs('.mobile-nav');
    if (toggle && mobileNav) {
      toggle.addEventListener('click', () => {
        const isOpen = document.body.classList.toggle('nav-open');
        mobileNav.classList.toggle('active', isOpen);
        document.body.style.overflow = isOpen ? 'hidden' : '';
      });
      qsa('.mobile-nav a').forEach(link => {
        link.addEventListener('click', () => {
          document.body.classList.remove('nav-open');
          mobileNav.classList.remove('active');
          document.body.style.overflow = '';
        });
      });
    }
  }

  // ─── 4. HERO ANIMATION ───────────────────────────────────
  function initHeroAnimation() {
    if (prefersReducedMotion) return;

    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

    tl.from('.hero-eyebrow', { y: 20, opacity: 0, duration: 0.7, delay: 0.1 })
      .from('.hero-heading', { y: 40, opacity: 0, duration: 0.9 }, '-=0.4')
      .from('.hero-sub',     { y: 30, opacity: 0, duration: 0.7 }, '-=0.6')
      .from('.hero-cta .btn', { y: 20, opacity: 0, duration: 0.5, stagger: 0.1 }, '-=0.4')
      .from('.hero-stats',   { y: 20, opacity: 0, duration: 0.5 }, '-=0.3')
      .from('.hero-visual',  { x: 40, opacity: 0, duration: 1.0, ease: 'power2.out' }, '-=0.8')
      .from('.floating-tag', { y: 30, opacity: 0, scale: 0.8, stagger: 0.15, duration: 0.5, ease: 'spring' }, '-=0.4')
      .from('.scroll-hint',  { opacity: 0, duration: 0.5 }, '-=0.2');
  }

  // ─── 5. BEFORE / AFTER SLIDER ────────────────────────────
  function initBeforeAfter() {
    const containers = qsa('.before-after-card');
    containers.forEach(card => {
      const range    = card.querySelector('.ba-range');
      const afterImg = card.querySelector('.after-img');
      const divider  = card.querySelector('.before-after-divider');
      const handle   = card.querySelector('.ba-handle');
      if (!range) return;

      function update(val) {
        const pct = val + '%';
        if (afterImg) afterImg.style.clipPath = `inset(0 ${100 - val}% 0 0)`;
        if (divider)  divider.style.left = pct;
        if (handle)   handle.style.left  = pct;
      }

      range.addEventListener('input', () => update(range.value));
      update(50);
    });
  }

  // ─── 6. SCROLL REVEAL ────────────────────────────────────
  function initScrollReveal() {
    if (prefersReducedMotion) {
      qsa('[data-reveal]').forEach(el => el.classList.add('revealed'));
      return;
    }

    qsa('[data-reveal]').forEach(el => {
      const type  = el.dataset.reveal || 'up';
      const delay = parseFloat(el.dataset.delay || 0);

      ScrollTrigger.create({
        trigger: el,
        start: 'top 88%',
        onEnter: () => {
          gsap.to(el, {
            opacity: 1,
            y: 0,
            x: 0,
            scale: 1,
            duration: 0.8,
            delay,
            ease: 'power3.out',
          });
          el.classList.add('revealed');
        },
        once: true,
      });

      // Initial state
      if (type === 'up')   gsap.set(el, { opacity: 0, y: 50 });
      if (type === 'fade') gsap.set(el, { opacity: 0 });
      if (type === 'left') gsap.set(el, { opacity: 0, x: -40 });
      if (type === 'right')gsap.set(el, { opacity: 0, x: 40 });
      if (type === 'scale')gsap.set(el, { opacity: 0, scale: 0.85 });
    });
  }

  // ─── 7. STAGGER REVEAL GROUPS ────────────────────────────
  function initStaggerGroups() {
    if (prefersReducedMotion) return;

    qsa('[data-stagger]').forEach(group => {
      const children = qsa('[data-stagger-item]', group);
      if (!children.length) return;

      gsap.set(children, { opacity: 0, y: 40 });

      ScrollTrigger.create({
        trigger: group,
        start: 'top 85%',
        onEnter: () => {
          gsap.to(children, {
            opacity: 1,
            y: 0,
            duration: 0.7,
            stagger: 0.09,
            ease: 'power3.out',
          });
        },
        once: true,
      });
    });
  }

  // ─── 8. PACK CARD MAGNETIC HOVER ─────────────────────────
  function initMagneticCards() {
    if (isMobile() || prefersReducedMotion) return;

    qsa('.pack-card').forEach(card => {
      const inner = card.querySelector('.pack-card-inner');

      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const cx   = rect.left + rect.width / 2;
        const cy   = rect.top  + rect.height / 2;
        const dx   = (e.clientX - cx) / (rect.width  / 2);
        const dy   = (e.clientY - cy) / (rect.height / 2);

        gsap.to(card, {
          rotateX: dy * -5,
          rotateY: dx * 5,
          duration: 0.5,
          ease: 'power2.out',
          transformPerspective: 1000,
          transformOrigin: 'center',
        });

        // Move inner highlight
        if (inner) {
          gsap.to(inner, {
            backgroundImage: `radial-gradient(circle at ${(dx + 1) * 50}% ${(dy + 1) * 50}%, rgba(0,102,255,0.06) 0%, transparent 60%)`,
            duration: 0.3,
          });
        }
      });

      card.addEventListener('mouseleave', () => {
        gsap.to(card, {
          rotateX: 0, rotateY: 0,
          duration: 0.6, ease: 'spring',
        });
        if (inner) {
          gsap.to(inner, {
            backgroundImage: 'none',
            duration: 0.3,
          });
        }
      });
    });
  }

  // ─── 9. FAQ ACCORDION ────────────────────────────────────
  function initFAQ() {
    const items = qsa('.faq-item');
    items.forEach(item => {
      const question = item.querySelector('.faq-question');
      if (!question) return;

      question.addEventListener('click', () => {
        const isActive = item.classList.contains('active');

        // Close all
        items.forEach(i => i.classList.remove('active'));

        // Open clicked (unless it was open)
        if (!isActive) item.classList.add('active');
      });
    });
  }

  // ─── 10. COUNTER ANIMATION ───────────────────────────────
  function initCounters() {
    qsa('[data-count]').forEach(el => {
      const target = parseFloat(el.dataset.count);
      const suffix = el.dataset.suffix || '';
      const prefix = el.dataset.prefix || '';

      ScrollTrigger.create({
        trigger: el,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo({ val: 0 },
            { val: 0 },
            {
              val: target,
              duration: 1.8,
              ease: 'power2.out',
              onUpdate: function () {
                const v = this.targets()[0].val;
                el.textContent = prefix + (Number.isInteger(target) ? Math.round(v) : v.toFixed(1)) + suffix;
              }
            }
          );
        },
        once: true,
      });
    });
  }

  // ─── 11. MARQUEE PAUSE ON HOVER ──────────────────────────
  function initMarquee() {
    qsa('.marquee-wrapper').forEach(wrapper => {
      const track = wrapper.querySelector('.marquee-track');
      if (!track) return;

      // Duplicate items for seamless loop
      const clone = track.cloneNode(true);
      wrapper.querySelector('.marquee-outer')?.appendChild(clone);

      wrapper.addEventListener('mouseenter', () => {
        track.style.animationPlayState = 'paused';
      });
      wrapper.addEventListener('mouseleave', () => {
        track.style.animationPlayState = 'running';
      });
    });
  }

  // ─── 12. SMOOTH ANCHOR SCROLL ────────────────────────────
  function initSmoothScroll() {
    qsa('a[href^="#"]').forEach(link => {
      link.addEventListener('click', (e) => {
        const id     = link.getAttribute('href');
        const target = qs(id);
        if (!target) return;
        e.preventDefault();
        const offset = 80;
        const top    = target.getBoundingClientRect().top + window.pageYOffset - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      });
    });
  }

  // ─── 13. NOTIFY FORM ─────────────────────────────────────
  function initNotifyForm() {
    const form = qs('.notify-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = form.querySelector('.notify-input');
      const btn   = form.querySelector('.btn-primary');
      if (!input || !input.value) return;

      // Visual success state
      if (btn) {
        btn.textContent = 'You\'re in! ✓';
        btn.style.background = 'var(--success)';
        btn.style.color = '#000';
      }
      input.value = '';
      setTimeout(() => {
        if (btn) {
          btn.textContent = 'Notify Me';
          btn.style.background = '';
          btn.style.color = '';
        }
      }, 3000);
    });
  }

  // ─── 14. PARALLAX ORBS ───────────────────────────────────
  function initParallax() {
    if (isMobile() || prefersReducedMotion) return;

    const orbs = qsa('.hero-orb');
    document.addEventListener('mousemove', (e) => {
      const cx = window.innerWidth  / 2;
      const cy = window.innerHeight / 2;
      const dx = (e.clientX - cx) / cx;
      const dy = (e.clientY - cy) / cy;

      orbs.forEach((orb, i) => {
        const factor = (i + 1) * 12;
        gsap.to(orb, {
          x: dx * factor,
          y: dy * factor,
          duration: 1.5,
          ease: 'power2.out',
        });
      });
    });
  }

  // ─── 15. SECTION LABEL GLOW ──────────────────────────────
  function initSectionGlow() {
    qsa('.section-eyebrow').forEach(el => {
      ScrollTrigger.create({
        trigger: el,
        start: 'top 90%',
        onEnter: () => {
          gsap.from(el, {
            opacity: 0,
            x: -20,
            duration: 0.6,
            ease: 'power3.out',
          });
        },
        once: true,
      });
    });
  }

  // ─── 16. PACK CARD ADD-TO-CART ───────────────────────────
  function initPackButtons() {
    qsa('[data-add-to-cart]').forEach(btn => {
      const variantId = btn.dataset.addToCart;
      btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<span>Adding…</span>';
        btn.style.opacity = '0.7';
        btn.style.pointerEvents = 'none';

        try {
          const res = await fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: variantId, quantity: 1 }),
          });

          if (!res.ok) throw new Error('Add to cart failed');

          btn.innerHTML = '✓ Added!';
          btn.style.background = 'var(--success)';
          btn.style.color = '#000';
          btn.style.opacity = '1';

          // Update cart count
          updateCartCount();

          setTimeout(() => {
            btn.innerHTML = originalHTML;
            btn.style.background = '';
            btn.style.color = '';
            btn.style.pointerEvents = '';
          }, 2500);
        } catch (err) {
          btn.innerHTML = originalHTML;
          btn.style.opacity = '1';
          btn.style.pointerEvents = '';
        }
      });
    });
  }

  async function updateCartCount() {
    try {
      const res  = await fetch('/cart.js');
      const cart = await res.json();
      const counts = qsa('.cart-count');
      counts.forEach(el => {
        el.textContent = cart.item_count;
        el.style.display = cart.item_count ? 'flex' : 'none';
      });
    } catch (e) { /* silent */ }
  }

  // ─── INIT ─────────────────────────────────────────────────
  function init() {
    initLoader();
    initCursor();
    initHeader();
    initBeforeAfter();
    initScrollReveal();
    initStaggerGroups();
    initMagneticCards();
    initFAQ();
    initCounters();
    initMarquee();
    initSmoothScroll();
    initNotifyForm();
    initParallax();
    initSectionGlow();
    initPackButtons();

    // Refresh ScrollTrigger after fonts load
    document.fonts.ready.then(() => ScrollTrigger.refresh());
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
